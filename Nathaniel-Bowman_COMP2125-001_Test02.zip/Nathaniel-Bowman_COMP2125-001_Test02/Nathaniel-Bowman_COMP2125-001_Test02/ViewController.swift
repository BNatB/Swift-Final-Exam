//
//  ViewController.swift
//  Nathaniel-Bowman_COMP2125-001_Test02
//
//  Created by user212399 on 8/15/22.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var lblStudentId: UITextField!
    
    @IBOutlet weak var txtStudentName: UITextField!
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtAddress: UITextField!
    
    //random 6-digit number
    let randomNum: Int = Int.random(in: 100000..<999999)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btnGenerateTapped(_ sender: Any) {
        //assign randomNum to lblStudentId through button press because it did not work in viewDidLoad()
        lblStudentId.text = String(randomNum);
    }
    
    @IBAction func btnNextTapped(_ sender: Any) {
        //checks if fields are empty
        if (txtStudentName.text != "" && txtEmail.text != ""){
            //creates new view controller
            let courseVC: CourseDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "CourseDetailsViewController") as! CourseDetailsViewController;
            
            //assigns data to new controller
            courseVC.studentName = txtStudentName.text!;
            courseVC.email = txtEmail.text!;
            courseVC.address = txtAddress.text!;
            courseVC.studentID = randomNum;
            
            //naviagate to new controller
            self.navigationController?.pushViewController(courseVC, animated: true);
        }
        else{
            //print in console if empty
            print("studentName and/or email are empty!")
        }
    }
}

