//
//  RegisterDetailsViewController.swift
//  Nathaniel-Bowman_COMP2125-001_Test02
//
//  Created by user212399 on 8/15/22.
//

import UIKit

class RegisterDetailsViewController: ViewController {
    
    
    
    @IBOutlet weak var txtRegStudentName: UITextField!
    
    @IBOutlet weak var txtRegCourseName: UITextField!
    
    @IBOutlet weak var txtRegCourseFee: UITextField!
    
    
    @IBOutlet weak var txtSemester: UITextField!
    
    
    
    @IBOutlet weak var regTextField: UITextView!
    
    
    //initial empty variables
    var regStudentName: String = "";
    var regEmail: String = "";
    var regAddress: String = "";
    var regStudentID: Int = 0;
    var regCourseID: Int = 0;
    var regCourseName: String = "";
    var regCredits: Int = 0;
    var regFees: Double = 0.0;

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        txtRegStudentName.text = regStudentName;
    }
    

    @IBAction func btnSubmitTapped(_ sender: Any) {
        let feeValue: Double = Double(regCredits) * regFees;
        
        //checks to see if fields are empty
        if(txtRegStudentName.text != "" && txtRegCourseName.text != "" && txtRegCourseFee.text != "" && txtSemester.text != ""){
            regTextField.text = "Student ID: \(regStudentID) \nStudent Name: \(regStudentName) \nCourse ID: \(regCourseID) \nCourse Name: \(regCourseName) \nCourse Fees: $\(feeValue) \nCourse Semester: \(txtSemester.text ?? "Fall")";
        }
        else{
            //prints error to user
            regTextField.text = "ERROR: Data incomplete, please try again!";
        }
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
