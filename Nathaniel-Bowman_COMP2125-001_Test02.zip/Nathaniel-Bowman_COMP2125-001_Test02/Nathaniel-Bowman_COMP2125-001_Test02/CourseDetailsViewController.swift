//
//  CourseDetailsViewController.swift
//  Nathaniel-Bowman_COMP2125-001_Test02
//
//  Created by user212399 on 8/15/22.
//

import UIKit

class CourseDetailsViewController: ViewController {
    
    
    @IBOutlet weak var txtCourseID: UITextField!
    

    @IBOutlet weak var txtCourseName: UITextField!
    
    
    @IBOutlet weak var txtCredits: UITextField!
    
    @IBOutlet weak var txtFeePerCredit: UITextField!
    
    
    @IBOutlet weak var courseField: UITextView!
    
    //initial empty variables
    var studentName: String = "";
    var email: String = "";
    var address: String = "";
    var studentID: Int = 0;
    
    //random 3-digit number
    let randomNum2: Int = Int.random(in: 100..<999)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnDisplayTapped(_ sender: Any) {
        //assign course ID
        txtCourseID.text = String(randomNum2);
        
        //checks to see if fields are empty
        if(txtCourseName.text != "" && txtCredits.text != "" && txtFeePerCredit.text != ""){
            //prints data in text field
            courseField.text = "Course ID: \(txtCourseID.text ?? "Course ID") \nCourse Name: \(txtCourseName.text ?? "Course Name") \nCourse Credits: \(txtCredits.text ?? "Course Credits") \nCourse Fees per Credit: \(txtFeePerCredit.text ?? "Fees/Credit")";
        }
        else{
            //prints error to user
            courseField.text = "ERORR: Course Name, Credits, or Fees are empty!";
        }
    }
    
    
    
    @IBAction func btnCourseNextTapped(_ sender: Any) {
        if(txtCourseName.text != "" && txtCredits.text != "" && txtFeePerCredit.text != ""){
            let registerVC: RegisterDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "RegisterDetailsViewController") as! RegisterDetailsViewController;
            
            //convert credits and fees to int and double respectively
            let creditString: String = txtCredits.text ?? "";
            let creditInt: Int = Int(creditString) ?? 0;
            let feeString: String = txtFeePerCredit.text ?? "";
            let feeDouble: Double = Double(feeString) ?? 0.0;
            
            //pass data to new view controller
            registerVC.regStudentID = studentID;
            registerVC.regStudentName = studentName;
            registerVC.regEmail = email;
            registerVC.regCourseID = randomNum2;
            registerVC.regCourseName = txtCourseName.text!;
            registerVC.regCredits = creditInt;
            registerVC.regFees = feeDouble;
            
            //navigate to new controller
            self.navigationController?.pushViewController(registerVC, animated: true);
        }
        else{
            print("Name, Credits, or Fees are empty!");
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
